# ROR-project
This a simple rails application that consists of a receptionist portal &amp; doctor portal which performs the following tasks, 1. A single login page for both portals. 2. Receptionists can register a new patient &amp; perform CRUD operations. 3. Doctors can view registered patients &amp; view the graph that represents the number of patients registered vs days
